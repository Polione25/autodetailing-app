
document.getElementById("root").innerHTML = "<h2>PoliOne App bereit! (React-Inhalt später gebündelt)</h2>";
