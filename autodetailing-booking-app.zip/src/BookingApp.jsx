<img src="/assets/logo-schrift.png" alt="PoliOne Logo" className="h-16 mx-auto" />
bitte 
